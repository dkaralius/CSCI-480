/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 6          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Wednesday, 11/13/2019          *
 *                                                          *
 *  Assign6.cc                                              *
 *                                                          *
 *  This program simulates memory block management, through *
 *  various transactions, including; load, allocate,        *
 *  deallocate, and terminate.                              *
 ***********************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <fstream>
#include <list>
#include <queue>
#include <stddef.h>
#include <stddef.h>
#include <sstream>
#include <algorithm>

//Constants
#define HOWOFTEN  5
#define KB 1024
#define MB KB * KB

using namespace std;

//Class definition for a memory block
class Block
{
	public:
		int startingAddress; //Starting address
		int size;            //Size of memory block
		int pid;             //PID of memory block
		string id;           //ID of memory black
		Block* previous = NULL;
		Block* next = NULL;
	public:
		Block(int size, int startingAddress)
		{
			this->size = size;
			this->startingAddress = startingAddress;
		}
};

//List that contains blocks that are not presently in use
list<Block> ninUse;
//List that contains blocks that are presently in use
list<Block> inUse;

//Function prototypes
void bestFitRun();
void bestFitLoad(string);
void firstFitRun();
void firstFitLoad(string);
void insertBlock(Block);
void kill(string);
void deallocate(string);
void print();

//Set the starting address to default value, for sake of assignment
int startingAddress = 3 * 1024 * 1024;

int main(int argc, char *argv[])
{
	char buffer = '?';

	//Check if user provided argument
	if(argc > 1)
	{
		buffer = argv[1][0];//Get argument provided by user

		//Buffer has to be B,b,f, or F.
		if(!(buffer == 'B' || buffer == 'F') && !(buffer == 'b' || buffer == 'f'))
		{
			cerr << endl << "Invalid argument. Please use B or F." << endl;
		}

		//Declare initial sizes of memory blocks
		int sizes[5] = {MB, 2* MB, 2* MB, 4 * MB, 4 * MB};

		//Create 5 new memory blocks and push them to list of ninUse(not in use)
		for (int i = 0; i < 5; i++)
		{
			ninUse.push_back(*(new Block(sizes[i], startingAddress)));
			startingAddress = startingAddress + sizes[i];
		}

		//If argument is  B or b, start best fit algo
		if(buffer  == 'B' || buffer == 'b')
		{
			cerr << endl << "Simulation of Memory Management using the Best-Fit algorithm" << endl << endl;
			cerr << "Beginning of the run" << endl << endl;
			bestFitRun();
		}
		//Else, start first fit algo
		else if(buffer  == 'F' || buffer == 'f')
		{
			cerr << endl << "Simulation of Memory Management using the First-Fit algorithm" << endl << endl;
                        cerr << "Beginning of the run" << endl << endl;
                        firstFitRun();
		}
	}
	//If not, print error message and exit
	else
	{
		cerr << endl << "No arguments provided. Please provide an argument." << endl << endl;
		exit(-1);
	}
}
/***************************************************************
bestFitRun()

Use: Runs the best-fit algorithm. Starts out by opening the text
     file and checking if there was an error opening it or not.
     Then reads the whole file and sees what transaction type
     is next. For each transaction type, goes to another function
     After each transaction, reprint status of memory blocks.
     At the end of file, close the file. And print final status
     of memory blocks.

Parameters: None

Returns: Nothing
***************************************************************/
void bestFitRun()
{
	ifstream file;
	file.open("/home/turing/t90hch1/csci480/Assign6/data6.txt");
	//file.open("data6.txt");

	if(file.fail())
	{
		cerr << endl << "Error opening the file.";
		exit(-1);
	}
	string line;
	char buffer = '?';
	int count = 0;
	print();

	while(!file.eof())
        {
                getline(file,line);
                buffer = line[0];

		//If 'L', load transaction
                if(buffer == 'L') //Load
                {
			bestFitLoad(line); //Load transaction with best-fit
                }
                if(buffer == 'T') //Terminate
                {
			kill(line); //Terminate the process
                }
                if(buffer == 'A') //Allocate
                {
			bestFitLoad(line); //Allocate transaction with best-fit
                }
                if(buffer == 'D') //Deallocate
                {
			deallocate(line); //Deallocate transaction with best-fit
                }
                if(buffer == '?') //Kill program
                {
                        break;
                }
                print();
        }
        file.close();
        cerr << "End of the run" << endl << endl;
        print();
}
/***************************************************************
firstFitRun()

Use: Runs the first-fit algorithm. Starts out by opening the text
     file and checking if there was an error opening it or not.
     Then reads the whole file and sees what transaction type
     is next. For each transaction type, goes to another function
     After each transaction, reprint status of memory blocks.
     At the end of file, close the file. And print final status
     of memory blocks.

Parameters: None

Returns: Nothing
***************************************************************/
void firstFitRun()
{
        ifstream file;
        file.open("/home/turing/t90hch1/csci480/Assign6/data6.txt");
	//file.open("data6.txt");

	if(file.fail())
        {
                cerr << endl << "Error opening the file.";
                exit(-1);
        }
        string line;
        char buffer = '?';
        print();

	while(!file.eof())
	{
		getline(file,line);
		buffer = line[0];
		if(buffer == 'L') //Load transaction with first-fit
		{
			firstFitLoad(line);
		}
		if(buffer == 'T') //Terminate the process
		{
			kill(line);
		}
		if(buffer == 'A') //Allocate transaction with first-fit
		{
			firstFitLoad(line);
		}
		if(buffer == 'D') //Deallocate
		{
			deallocate(line); //Deallocate transaction with first-fit
		}
		if(buffer == '?') //Kill program
		{
			break;
		}
		print();
	}
	file.close();
	cerr << "End of the run" << endl << endl;
	print();
}
/***************************************************************
bestFitLoad(string slacker)

Use: Load transaction for the best-fit algorithm. Since this is
     identical to allocate, it checks to see if buffer was L or
     A, and just prints a different header. Cycles through the
     list of not in use (ninUse) list of memory blocks, and
     checks to see if there is a block that is big enough to
     load the desired process. If there is, it loads and then
     pushes the Block to the in use (inUse) list of memory blocks.
     If not, prints error message.

Parameters: string slacker - A string that represents whole line
                             from the input file.

Returns: Nothing
***************************************************************/
void bestFitLoad(string slacker)
{
	char buffer; //L,T,A,D, or ? (1st value)
	int pid; //PID of block (2nd value)
	int size; //Size of block (3rd value)
	string id; //ID of block (4th value)

	bool available = false; //Initiate to false

	istringstream str(slacker); //Load string into str buffer, to be parsed
	str >> buffer >> pid >> size >> id;

	//Create 2 iterators
	list<Block>::iterator it;
	list<Block>::iterator it2;

	int mem = 15 * MB;

	//Since Allocate and Load are identical, just print different headers
	if(buffer == 'L')
	{
		//Print header
		cerr << "Transaction:  request to load process " << pid << ", block ID "
		     << id << " using " << size << " bytes" << endl;
	}
	else if(buffer == 'A')
	{
		//Print header
		cerr << "Transaction:  request to allocate " << size << " bytes for process "
            	     << pid << ", block ID: " << id << endl;
	}
	for(it = ninUse.begin(); it != ninUse.end(); it++)
	{
		if((it->size - size) < mem && (it->size - size) > 0)
		{
			mem = (it->size - size);
			it2 = it;
			available = true;
		}
	}

	if(available)
	{
		cerr << "Found a block of size " << it2->size << endl;
		it2->size = it2->size - size;

		Block temp(size, it2->startingAddress);

		it2->startingAddress = it2->startingAddress + size;
		temp.pid = pid;
		temp.id = id;
		inUse.push_front(temp);

		cerr << "Success in allocating a block" << endl << endl;
	}
	else
	{
		cerr << "Unable to comply as no block of adequate size is available " << endl << endl;
	}

}
/***************************************************************
firstFitLoad(string slacker)

Use: Load transaction for the first-fit algorithm. Since this is
     identical to allocate, it checks to see if buffer was L or
     A, and just prints a different header. Cycles through the
     list of not in use (ninUse) list of memory blocks, and
     checks to see if there is a block that is big enough to
     load the desired process. If there is, it loads and then
     pushes the Block to the in use (inUse) list of memory blocks.
     If not, prints error message.

Parameters: string slacker - A string that represents whole line
                             from the input file.

Returns: Nothing
***************************************************************/
void firstFitLoad(string slacker)
{
        char buffer; //L,T,A,D, or ? (1st value)
        int pid; //PID of block (2nd value)
        int size; //Size of block (3rd value)
        string id; //ID of block (4th value)

        bool available = false; //Initiate to false

        istringstream str(slacker); //Load string into str buffer, to be parsed
        str >> buffer >> pid >> size >> id;

        //Create 2 iterators
        list<Block>::iterator it;
        list<Block>::iterator it2;

	//Since Allocate and Load are identical, just print different headers
        if(buffer == 'L')
        {
                //Print header
                cerr << "Transaction:  request to load process " << pid << ", block ID "
                     << id << " using " << size << " bytes" << endl;
        }
        else if(buffer == 'A')
        {
                //Print header
                cerr << "Transaction:  request to allocate " << size << " bytes for process "
                     << pid << ", block ID: " << id << endl;
        }


        for(it = ninUse.begin(); it != ninUse.end(); it++)
        {
                if((it->size - size) >= 0)
                {
			cerr << "Found a block of size " << it->size << endl;
			available = true;
			break;
                }
        }

        if(available)
	{
                it->size = it->size - size;
                Block temp(size, it->startingAddress);
		it->startingAddress = it->startingAddress + size;
                temp.pid = pid;
                temp.id = id;
                inUse.push_front(temp);

                cerr << "Success in allocating a block" << endl << endl;
        }
	else
        {
                cerr << "Unable to comply as no block of adequate size is available " << endl << endl;
        }
}
/***************************************************************
insertBlock(Block temp)

Use: Function that is used to merge blocks of memory. This function
     is called during the kill(string slacker) process, inorder
     to prevent 'empty' blocks.

Parameters: Block temp - A Block object

Returns: Nothing
***************************************************************/
void insertBlock(Block temp)
{
	//Bool check to see if it was inserted successfully
	bool inserted = false;

	//Iterators for Block
        list<Block>::iterator it;
        list<Block>::iterator it2;

	for(it = ninUse.begin(); it != ninUse.end(); it++)
	{
		if(it->startingAddress > temp.startingAddress)
		{
			ninUse.insert(it,temp);
			inserted = true;
			break;
		}
	}

	if(!inserted)
	{
		ninUse.push_front(temp);
	}

	for(it = ninUse.begin(); it != --ninUse.end(); it++)
	{
		it2 = it;
		it2++;

		if((it->size + it->startingAddress) == (it2->startingAddress))
		{
			if((it->size + it2->size) <= 4*MB)
			{
				cerr << "Merging two blocks at " << it->startingAddress
				     << " and " << it2->startingAddress << endl;

				it->size = it->size + it2->size;
				ninUse.erase(it2);
				it--;
			}
		}
	}
}
/***************************************************************
kill(string slacker)

Use: Terminate(kill) transaction. Checks to see if desired process
to be terminated actually exists. If it does, erases it and merges
the empty blocks and prints message on success.

Parameters: string slacker - A string that represents whole line
                             from the input file.

Returns: Nothing
***************************************************************/
void kill(string slacker)
{
	char buffer; //L,T,A,D, or ? (1st value)
        int pid; //PID of block (2nd value)

        bool terminated = false; //Initiate to false

        istringstream str(slacker); //Load string into str buffer, to be parsed
        str >> buffer >> pid;

	//Iterator for Block
	list<Block>::iterator it;


	//Print header
        cerr << "Transaction:  request to terminate process " << pid << endl;

	for(it = inUse.begin(); it != inUse.end(); it++)
	{
		if(it->pid == pid)
		{
			insertBlock(*(new Block(it->size, it->startingAddress)));
			inUse.erase(it);
			it--;
			terminated = true;
		}
	}
	//If termination was successfull, print message
	if(terminated)
	{
		cerr << "Success in terminating a process" << endl << endl;
	}
	//If desired PID did not exist, print error message
	else
	{
		cerr << "Unable to comply as the indicated process could not be found" << endl << endl;
	}
}
/***************************************************************
deallocate(string slacker)

Use: Deallocate transaction. Deallocates a memory block.

Parameters: string slacker - A string that represents whole line
                             from the input file.

Returns: Nothing
***************************************************************/
void deallocate(string slacker)
{
	char buffer; //L,T,A,D, or ? (1st value)
        int pid; //PID of block (2nd value)
        string id; //ID of block (3rd value)


        istringstream str(slacker); //Load string into str buffer, to be parsed
        str >> buffer >> pid >> id;

        //Create block iterator
        list<Block>::iterator it;

	//Print header
	cerr << "Transaction:  request to deallocate block ID " << id << " for process " << pid << endl;

	//Iterator through memory block that is in use
	for(it = inUse.begin(); it != inUse.end(); it++)
	{
		if(it->pid == pid && it->id == id)
		{
			insertBlock(*(new Block(it->size, it->startingAddress)));
			inUse.erase(it);
			cerr << "Success in deallocating a block" << endl << endl;
			return;
		}
	}
	cerr << "Unable to comply as the indicated block cannot be found" << endl << endl;
}
/***************************************************************
print()

Use: Standard print method. Prints the status of the memory
blocks. Information such as; starting address, size, PID, and ID.
Also prints the total number of blocks in use, not in use, and total
sizes of those lists.

Parameters: None

Returns: Nothing
***************************************************************/
void print()
{
	int count = 0; //Counter for total number of memory blocks

	//Create block iterator
        list<Block>::iterator it;

	//Print header
	cerr << "List of available blocks" << endl;

	if(ninUse.size() > 0)
	{
		for(it = ninUse.begin(); it != ninUse.end(); it++)
		{
			cerr << "Start Address = " << it->startingAddress << " Size = "
			     << it->size << endl;
			count += it->size;
		}
	}
	//If no blocks not in use, print (none)
	else
	{
		cerr << "(none)" << endl;
	}

	cerr << "Total size of the list = " << count << endl << endl;
	cerr << "List of blocks in use" << endl;

	count = 0; //Set counter back to zero, to count number of memory blocks in use

	if(inUse.size() > 0)
	{
		for(it = inUse.begin(); it != inUse.end(); it++)
		{
			cerr << "Start address = " << it->startingAddress;
			cerr << " Size = " << it->size;
			cerr << " Process ID = " << it->pid;
			cerr << " Block ID = " << it->id << endl;

			count += it->size;
		}
	}
	//If there are no blocks in use, print (none)
	else
	{
		cerr << "(none)" << endl;
	}

	cerr << "Total size of the list = " << count << endl << endl;
}
