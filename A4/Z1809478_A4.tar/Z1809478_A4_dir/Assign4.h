/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 4          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Monday, 10/14/2019             *
 *                                                          *
 *  Assign4.h                                               *
 *                                                          *
 *  Header file for Assign4.cpp, this file contains the     *
 *  constants that are used within the program.             *
 *                                                          *
 ***********************************************************/
#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#include <string>
#include <queue>

using namespace std;

const int MAX_TIME = 500;
const int IN_PLAY = 6;
const int QUEUE_SIZE = 20;
const int ARRAY_SIZE = 10;
const int HOW_OFTEN = 25;

#endif
