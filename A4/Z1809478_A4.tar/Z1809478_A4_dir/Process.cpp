/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 4          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Monday, 10/14/2019             *
 *                                                          *
 *  Process.cpp                                             *
 *                                                          *
 *  Contains the default contructor of the Process struct   *
 *  and a function that is used to increment CPU, Input, and*
 *  Output totals, aswell as decrementing the timers for    *
 *  each.                                                   *
 ***********************************************************/
#include "Process.h"

//Default starting PID number, specified by assignment
int Process::PIDNum = 101;

/***************************************************************
Process()

Default constructor of Process, that takes no arguments.
Generates a Process object with null value data members.
***************************************************************/
Process::Process()
{
}

/***************************************************************
Process(char*, char*)

Alternate constructor that takes two char* arguments.
	a - Represents 1st line of input
	b - Represents 2nd line of input

Tokenizes 'a' into process name, priority and arrival time.
Tokenizes 'b' into History values.

Sets values of data members to zero.
Sets process ID to PID number and incrememnts PID number.
***************************************************************/
Process::Process(char* a, char* b)
{
	//Tokenizes the 1st line of input
	char* slacker = strtok(a, " ");

	//First token is the process name
	ProcessName = slacker;

	//Second token is priority of process
	slacker = strtok(nullptr, " ");
	Priority = atoi(slacker);

	//Third token is arrival time of process
	slacker = strtok(nullptr, " ");
	ArrivalTime  = atoi(slacker);

	//Tokenizes the 2nd line of input
	slacker = strtok(b, " ");

	//The second line of input contains History values
	for (int i = 0; i < ARRAY_SIZE && slacker != nullptr; i++)
	{
		History[i][0] = slacker[0];

		slacker = strtok(nullptr, " ");
		History[i][1] = atoi(slacker);

		slacker = strtok(nullptr, " ");
	}

	//Set variables to zero
	Sub = 0;
	CPUTimer = 0;
	IOTimer = 0;
	CPUTotal = 0;
	ITotal = 0;
	OTotal = 0;
	CPUCount = 0;
	ICount = 0;
	OCount = 0;
	LastSeen = 0;
        WaitingTime = 0;

	//Set the process ID to the PID number
	ProcessID = PIDNum;

	//Incrememnt the PID number, so 2 processes won't have same values
	PIDNum++;
}
/***************************************************************
Process::clockTick()

Use: Looks at the value of History at current subscript to
     determine what to do.
	C - Decrement CPUTimer and increment CPUTotal
	I - Decrement IOTimer and increment ITotal
	O - Decrement IOTimer and increment OTotal

Parameters: None

Returns: Nothing
***************************************************************/
void Process::clockTick()
{
	switch (History[Sub][0])
	{
		//CPU burst
		case 'C':
			CPUTimer--;
			CPUTotal++;
			break;
		//Input burst
		case 'I':
			IOTimer--;
			ITotal++;
			break;
		//Output burst
		case 'O':
			IOTimer--;
			OTotal++;
			break;
	}
}
