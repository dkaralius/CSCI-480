/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 4          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Monday, 10/14/2019             *
 *                                                          *
 *  Process.h                                               *
 *                                                          *
 *  Header file for Process.cpp, contains the Process and   *
 *  ComparePriortiy structs.                                *
 ***********************************************************/
#ifndef PROCESS_H
#define PROCESS_H
#include "Assign4.h"

//Forward declaration of structs
struct Process;
struct ComparePriority;

/***************************************************************
Process

Structure type, named Process with members that will hold
information on the Process object.
***************************************************************/
struct Process
{
	Process(char*, char*);
	Process();
	string ProcessName;
	int Priority;
	int ProcessID;
	int ArrivalTime;
	char History[ARRAY_SIZE][2];
	short int Sub;
	short int IOTimer;
	short int CPUTotal;
	short int ITotal;
	short int OTotal;
	short int CPUCount;
	short int ICount;
	short int OCount;
	static int PIDNum;
	int StartTime;
	short int CPUTimer;
	int LastSeen;
        int WaitingTime;
	void clockTick();
};
/***************************************************************
ComparePriority

Structure type, named ComparePriority that allows us to compare
structs, in this case, Processes
***************************************************************/
struct ComparePriority
{
	bool operator()(const Process& lhs, const Process& rhs) const
	{
		if (lhs.Priority == rhs.Priority)
			return (lhs.LastSeen) > (rhs.LastSeen);
		else
			return lhs.Priority < rhs.Priority;
	}
};
#endif
