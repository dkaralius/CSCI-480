/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 4          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Monday, 10/14/2019             *
 *                                                          *
 *  Assign4.cpp                                             *
 *                                                          *
 *  This program simulates a priority scheduling system     *
 *  from a provided input file.                             *
 ***********************************************************/
#include "Assign4.h"
#include "Process.h"

//Queue of Process objects
queue<Process> process;
//Input file that we will read from
const char* file = "/home/turing/t90hch1/csci480/Assign4/data4.txt";
//Specialized priority queue
typedef priority_queue<Process, vector<Process>, ComparePriority> ProcessPriorityQueue;

//Process queue objects
ProcessPriorityQueue Ready;
ProcessPriorityQueue Input;
ProcessPriorityQueue Output;

//Pointers to processes
Process* Active;
Process* IActive;
Process* OActive;

//Temporary Process objects that will hold information
Process buffer;
Process ATemp;
Process ITemp;
Process OTemp;

//Global variables
bool waiting;
bool final;
int size;
int timer;
int idleTime;
int killedProcesses;

//Function prototypes
bool done();
void Print();
void PrintFinal();
void KillProcess(Process*);

int main()
{
	//Open input file and attempt to read it
	ifstream inFile;
	inFile.open(file);

	//If we cannot open the input file, print error message
	if (!inFile)
	{
		cerr << "Unable to open the input file! Closing program.";
		exit(-1);
	}

	//Buffers used to hold 1st and 2nd lines of input file
	char input1[256];
	char input2[256];

	while (inFile && inFile.peek() != -1)
	{

		if (inFile.peek() == '\n' || inFile.peek() == '\r')
		{
			inFile.ignore();
		}
		else
		{
			//Read 2 lines at a time
			inFile.getline(input1, 256);
			inFile.getline(input2, 256);

			//Create new process object
			process.push(Process(input1, input2));

			//Reset the buffer values
			memset(input1, '\0', 256);
			memset(input2, '\0', 256);
		}
	}

	//Closes the input file
	inFile.close();

	//Set default values for global variables
	waiting = true;
	final = false;
	timer = 0;
	idleTime = 0;
	killedProcesses = 0;
	Active = nullptr;
	IActive = nullptr;
	OActive = nullptr;

	//Print the header of program
	cerr << "Simulation of Priority Scheduling\n\n";

	//Main logic of program
	do
	{
		//Finds the total number of processes in the system
		size = (Ready.size() + Input.size() + Output.size());

		if(Active != nullptr)
		{
			size++;
		}
		if(IActive != nullptr)
		{
			size++;
		}
		if(OActive != nullptr)
		{
			size++;
		}

		//While size is less than maximum number of processes that can be in play at once and a process is waiting
		while(size < IN_PLAY && waiting)
		{
			buffer = process.front();
			process.pop();

			cout << "Process " << buffer.ProcessID;
			cout << " moved from the Entry Queue into the Ready Queue at time " << timer << endl << endl;

			buffer.LastSeen = timer;
			buffer.StartTime = timer;

			Ready.push(buffer);

			waiting = !(process.front().ArrivalTime > timer || process.front().ProcessName == "STOPHERE");
		}

		//Check if Active pointer is null and Ready queue is not empty
		if (Active == nullptr && !Ready.empty())
		{
			//Set Active as a pointer to top of Ready queue and pop Ready
			ATemp = Ready.top();
			Active = &ATemp;
			Ready.pop();

			//Calculate the total time that was spent waiting for Active
			Active->WaitingTime += (timer - Active->LastSeen);

			//Start CPUTimer countdown
			Active->CPUTimer = (short) Active->History[Active->Sub][1];
		}

		//If a process was active, add a clock tick
		if (Active != nullptr)
		{
			//Execute a clock tick based on where we are in History[Sub][0]
			Active->clockTick();

			//If CPU burst is finished
			if (Active->CPUTimer == 0)
			{
				//Increment the CPU Burst Counter
				Active->CPUCount++;

				//Increment the subscript for History
				Active->Sub++;

				//Check to see what happens next
				switch(Active->History[Active->Sub][0])
				{
					//If 'I', push to Input queue
					case 'I':
						Input.push(*Active);
						break;
					//If 'O', push to Output queue
					case 'O':
						Output.push(*Active);
						break;
					//If neither, kill the current process
					default:
						KillProcess(Active);
				}

				Active->LastSeen = timer;

				//Process is finished, set to null
				Active = nullptr;
			}
		}
		//Idle
		else
		{
			cout << endl << "At time " << timer << ", Active is 0, so we have idle time for a while";
			cout << endl << endl;

			//Incrememnt idle timer
			idleTime += 1;
		}

		//Check if IActive pointer is null and Input queue is not empty
		if (IActive == nullptr && !Input.empty())
		{
			//Set IActive as a pointer to top of Input queue and pop Input
			ITemp = Input.top();
			IActive = &ITemp;
			Input.pop();

			//Calculate the total time that was spent waiting for IActive
			IActive->WaitingTime += (timer - IActive->LastSeen);

			//Start IOTimer countdown
			IActive->IOTimer = (short) IActive->History[IActive->Sub][1];
		}

		//If a process was active, add a clock tick
		if (IActive != nullptr)
		{
			//Execute a clock tick based on where we are in History[Sub][0]
			IActive->clockTick();

			//If CPU burst is finished
			if (IActive->IOTimer == 0)
			{
				//Increment the input Burst counter
				IActive->ICount++;

				//Increment the history subscript
				IActive->Sub++;

				IActive->LastSeen = timer;
				Ready.push(*IActive);

				//Process is finished, set to null
				IActive = nullptr;
			}
		}
		//Check if OActive pointer is null and Output queue is not empty
		if (OActive == nullptr && !Output.empty())
		{
			//Set OActive as a pointer to top of Output queue and pop Output
			OTemp = Output.top();
			OActive = &OTemp;
			Output.pop();

			//Calculate the total time that was spent waiting for IActive
			OActive->WaitingTime += (timer - OActive->LastSeen);

			//Start IOTimer countdown
			OActive->IOTimer = (short) OActive->History[OActive->Sub][1];
		}
		//If a process was active, add a clock tick
		if (OActive != nullptr)
		{
			//Execute a clock tick based on where we are in History[Sub][0]
			OActive->clockTick();

			//If CPU burst is finished
			if (OActive->IOTimer == 0)
			{
				//Increment the output Burst counter
				OActive->OCount++;

				//Increment the history subscript
				OActive->Sub++;

				OActive->LastSeen = timer;
				Ready.push(*OActive);

				//Process is finished, set to null
				OActive = nullptr;
			}
		}


		//If timer is a multiple of HOWOFTEN, print out the state of the system
		if ((timer % HOW_OFTEN) == 0)
		{
			Print();
		}

		//Increment the timer
		timer++;

		//Make sure not to enter "stop here"
		waiting = !(process.front().ArrivalTime > timer || process.front().ProcessName == "STOPHERE");
	}while(!done());

	//Print final statistics and exit program
	PrintFinal();
	return 0;
}

/***************************************************************
Print

Use: A print function that first checks if it is at the end of
the program, using the bool 'final' variable. After that, it
prints the contents of the Entry, Ready, Input, and Output
queues.

Parameters: None

Returns: boolean value
		true  = timer has reached MAX_TIME or
		        Ready,Input, and Output queues are empty
		        and Active, IActive, and OActive are all
		        null
		false = Default
***************************************************************/
bool done()
{
	if(timer == MAX_TIME)
	{
		return true;
	}
	else if(Ready.empty() && Input.empty() && Output.empty()
		&& Active == nullptr && IActive == nullptr && OActive == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
/***************************************************************
Print

Use: A print function that first checks if it is at the end of
the program, using the bool 'final' variable. After that, it
prints the contents of the Entry, Ready, Input, and Output
queues.

Parameters: None

Returns: Nothing
***************************************************************/
void Print()
{
	//Temporary variables
	queue<Process> temp; //Used to hold process queue
	ProcessPriorityQueue temp1; //Used to hold Ready, Input, and Output queues

	//If this is the last time print will be called, print without "Status"
	if(final)
	{
		cout << "Active is at " << ((Active == nullptr)? 0 : Active->ProcessID) << endl;
		cout << "IActive is at " << ((IActive == nullptr)? 0 : IActive->ProcessID) << endl;
		cout << "OActive is at " << ((OActive == nullptr)? 0 : OActive->ProcessID) << endl;
	}
	//Else, print as usual
	else
	{
		cout << "Status at time " << timer << endl;
                cout << "Active is at " << ((Active == nullptr)? 0 : Active->ProcessID) << endl;
                cout << "IActive is at " << ((IActive == nullptr)? 0 : IActive->ProcessID) << endl;
                cout << "OActive is at " << ((OActive == nullptr)? 0 : OActive->ProcessID) << endl;
	}


	/*
                ENTRY QUEUE PRINT BLOCK
        */
	cout << "Contents of the Entry Queue:" << endl;

	//While process queue is not empty, copy contents into temp queue
	while (!process.empty())
	{
		if (process.front().ProcessName != "STOPHERE")
		{
			cout << process.front().ProcessID;
			cout << " Priority = " << process.front().Priority;
			cout << " arriving at time = " << process.front().ArrivalTime << endl;
		}

		temp.push(process.front());
		process.pop();
	}

	//Copy temp back into process
	process = temp;

	//Erase contents of temp queue
	while(!temp.empty())
	{
		temp.pop();
	}


	/*
                READY QUEUE PRINT BLOCK
        */
	cout << "Contents of the Ready Queue:" << endl;

	//If Ready queue is empty, print (Empty)
	if (Ready.empty())
	{
		cout << "(Empty)";
	}
	//Else, while its not empty, print process ID and priority for each process in queue
	else
	{
		while (!Ready.empty())
		{
			cout << Ready.top().ProcessID;
			cout << "(" << Ready.top().Priority << ")   ";

			temp1.push(Ready.top());
			Ready.pop();
		}

		//Copy temp1 back into Ready
		Ready = temp1;

		//Erase contents of temp1 queue
		while(!temp1.empty())
		{
			temp1.pop();
		}
	}
	cout << endl;


	/*
		INPUT QUEUE PRINT BLOCK
	*/
	cout << "Contents of the Input Queue:" << endl;

	//If Input queue is empty, print (Empty)
	if (Input.empty())
	{
		cout << "(Empty)";
	}
	//Else, while its not empty, print process ID and priority for each process in queue
	else
	{
		while (!Input.empty())
		{
			cout << Input.top().ProcessID;
			cout << "(" << Input.top().Priority << ")   ";

			temp1.push(Input.top());
			Input.pop();
		}

		//Copy temp1 back into Input
		Input = temp1;

		//Erase contents of temp1 queue again
		while (!temp1.empty())
		{
			temp1.pop();
		}
	}
	cout << endl;


	/*
                OUTPUT QUEUE PRINT BLOCK
        */
	cout << "Contents of the Output Queue:" << endl;

	//If Output queue is empty, print (Empty)
	if (Output.empty())
	{
		cout << "(Empty)";
	}
	//Else, while its not empty, print process ID and priority for each process in queue
	else
	{
		while (!Output.empty())
		{
			cout << Output.top().ProcessID;
			cout << "(" << Output.top().Priority << ")   ";

			temp1.push(Output.top());
			Output.pop();
		}

		//Copy temp1 back into Output
		Output = temp1;

		//Erase contents of temp1 queue for the last time
		while(!temp1.empty())
		{
			temp1.pop();
		}
	}

	cout << endl << endl;
}
/***************************************************************
PrintFinal

Use: A print function that is called at the end of the program.
It simply prints out a message to let the user know the program
has ended and some generic information about the processes.
It then sets the boolean value 'final' to true and then calls
the Print() function.

Parameters: None

Returns: Nothing
***************************************************************/
void PrintFinal()
{
	cout << endl << endl;
        cout << "The run has ended" << endl;
	cout << "The final value of the timer was: " << timer << endl;
	cout << "The amount of time spent in idle was: " << idleTime << endl;
        cout << "Number of terminated Processes = " << killedProcesses << endl;
	final = true;
	Print();
}
/***************************************************************
KillProcess

Use: After a process has been terminated, this function prints
out some information about the Process that was used as a
parameter. At the bottom of the function, increments the
'killedProcesses' variable, that will be used to let the user
know how many processes have been killed at the end of the
program.

Parameters: process, pointer to a Process object

Returns: Nothing
***************************************************************/
void KillProcess(Process* process)
{
	cout << endl << "A Process has terminated." << endl;
	cout << setw(20) << left << "Process ID:" << process->ProcessID << endl;
	cout << setw(20) << left << "Name:" << process->ProcessName << endl;
	cout << setw(20) << left << "Priority:" << process->Priority << endl;
	cout << setw(20) << left << "Started at time:" << process->StartTime
		<< " and ended at time " << timer << endl;
	cout << setw(20) << left << "Total CPU time:" << process->CPUTotal
		<< " in " << process->CPUCount << " CPU Bursts" << endl;
	cout << setw(20) << left << "Total Input time:" << process->ITotal
		<< " in " << process->ICount << " Input Bursts" << endl;
	cout << setw(20) << left << "Total Output time:" << process->OTotal
		 << " in " << process->OCount << " Output Bursts" << endl;
	cout << setw(20) << left << "Time spent waiting:" << process->WaitingTime;
	cout << endl << endl;

	killedProcesses++;
}
