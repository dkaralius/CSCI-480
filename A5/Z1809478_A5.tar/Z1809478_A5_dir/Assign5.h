/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 5          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Friday, 10/25/2019             *
 *                                                          *
 *  Assign5.h                                               *
 *                                                          *
 *  Header file for Assign5.cpp, this file contains the     *
 *  constants that are used within the program.             *
 *                                                          *
 ***********************************************************/
#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <list>

using namespace std;

const int BUFFER_SIZE = 35;
const int P_NUMBER = 7;
const int C_NUMBER = 5;
const int P_STEPS = 5;
const int C_STEPS = 7;

#endif
