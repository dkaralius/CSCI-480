/************************************************************
 *                                                          *
 *  CSCI 480            Assignment 5          Fall   2019   *
 *                                                          *
 *  Programmer:  Dominykas Karalius - Z1809478              *
 *                                                          *
 *  Date Due:    11:59 PM on Friday, 10/25/2019             *
 *                                                          *
 *  Assign5.cpp                                             *
 *                                                          *
 *  This program utilizes POSIX threads, semaphores and a   *
 *  mutex to illustrate the Producer-Consumer Problem.      *
 ***********************************************************/
#include "Assign5.h"

//Function Prototypes
void Insert(long,int);
void Remove(long);
void * Produce(void*);
void * Consume(void*);
void Print();

//Global Variables
pthread_mutex_t mutex;
sem_t NotFull;
sem_t NotEmpty;
list<pair<long,int>> Buffer;

int main()
{
	cerr << "Simulation of Producer and Consumers\n\n";

	int rc;//Integer value to see if there was an error

	//Declare pthreads
	pthread_t consumerThread[C_NUMBER];
	pthread_t producerThread[P_NUMBER];

	//Initialize semaphores
	sem_init(&NotFull, 0, BUFFER_SIZE);
	sem_init(&NotEmpty, 0, 0);

	//Try to initialize pthread
	rc = pthread_mutex_init(&mutex, NULL);

	if(rc)
	{
		cerr << "pthread_mutex_init failed! Exit code: " << rc;
		exit(-1);
	}

	cerr << "The semaphores and mutex have been initialized.\n\n";


	//Try to genereate producer threads
	for(long i = 0; i < P_NUMBER; i++)
	{
		rc = pthread_create(&producerThread[i], NULL, Produce, (void *) i);

		if(rc)
		{
			cerr << "pthread_create failed! Exit code: " << rc;
                	exit(-1);
		}
	}

	//Try to genereate consumer threads
        for(long i = 0; i < C_NUMBER; i++)
        {
                rc = pthread_create(&consumerThread[i], NULL, Consume, (void *) i);

                if(rc)
                {
                        cerr << "pthread_create failed! Exit code: " << rc;
                        exit(-1);
                }
        }

	//Try to join producer thread
	for(int i = 0; i < P_NUMBER; i++)
	{
		pthread_join(producerThread[i], NULL);
	}

	//Try to join consumer thread
	for(int i = 0; i < C_NUMBER; i++)
        {
		pthread_join(consumerThread[i], NULL);
        }

	cerr << "All the producer and consumer threads have been closed.\n\n";

	//Destroy semaphores and mutex
	sem_destroy(&NotFull);
	sem_destroy(&NotEmpty);
	pthread_mutex_destroy(&mutex);

	cerr << "The semaphores and mutex have been deleted.\n\n";

	return 0;
}
/***************************************************************
Insert

Use: Tries to lock the mutex, and if successful, inserts a
     threadID,widget pair to the list and then prints the contents
     of the list. After printing everything, unlocks the mutex.

Parameters: ThreadID - PID of a thread
	    widget   - Widget number that was generated

Returns: Nothing
***************************************************************/
void Insert(long ThreadID,int widget)
{
	int rc; //Integer value to see if there was an error

	rc = pthread_mutex_lock(&mutex); //Try to lock the mutex

	//If it was a failure, print error message
	if(rc)
	{
		cerr << "pthread_mutex_lock failed! Exit code: " << rc;
                exit(-1);
	}
	//Else, add the threadID, widget pair to the list and print contents of list
	else
	{
		pair<long,int> wpair(ThreadID, widget);
		Buffer.push_back(wpair);
		cerr << "Producer " << ThreadID << " inserted one item. " << " Total is now " << Buffer.size() << ".\n";
		Print();
	}

	pthread_mutex_unlock(&mutex); //Unlock the mutex
}
/***************************************************************
Remove

Use: Tries to lock the mutex, and if successful, removes a
     widget from the list and then prints the contents of the
     list. After printing everything, unlocks the mutex.

Parameters: ThreadID - PID of a thread

Returns: Nothing
***************************************************************/
void Remove(long ThreadID)
{
	int rc; //Integer value to see if there was an error

        rc = pthread_mutex_lock(&mutex); //Try to lock the mutex

        //If it was a failure, print error message
        if(rc)
        {
		cerr << "pthread_mutex_lock failed! Exit code: " << rc;
                exit(-1);
	}
        //Else, remove the widget from the list and print the list
        else
        {
		Buffer.pop_front();
		cerr << "Consumer " << ThreadID << " removed one item. " << " Total is now " << Buffer.size() << ".\n";
		Print();
	}

        pthread_mutex_unlock(&mutex); //Unlock the mutex
}
/***************************************************************
Produce

Use: Produces(creates) widgets

Parameters: ThreadID - PID of a thread

Returns: Nothing
***************************************************************/
void * Produce(void * ThreadID)
{
	int rc; //Integer value to see if there was an error

	long temp = (long) ThreadID;

	for(int i = 0; i < P_STEPS; i++)
	{
		rc = sem_wait(&NotFull);

		if(rc)
		{
			cerr << "sem_wait failed! Exit code: " << rc;
                        exit(-1);
		}
		else
		{
			Insert(temp,i);
		}

		rc = sem_post(&NotEmpty);

		if(rc)
		{
			cerr << "sem_post failed! Exit code: " << rc;
			exit(-1);
		}

		sleep(1);
	}

	pthread_exit(NULL); //Kill thread
}
/***************************************************************
Consume

Use: Consumes(removes) widgets

Parameters: ThreadID - PID of a thread

Returns: Nothing
***************************************************************/
void * Consume(void * ThreadID)
{
	int rc; //Integer value to see if there was an error

        long temp = (long) ThreadID;

        for(int i = 0; i < C_STEPS; i++)
        {
                rc = sem_wait(&NotEmpty);

                if(rc)
                {
			cerr << "sem_wait failed! Exit code: " << rc;
                        exit(-1);
                }
                else
                {
			Remove(temp);
                }

                rc = sem_post(&NotFull);

                if(rc)
                {
                        cerr << "sem_post failed! Exit code: " << rc;
			exit(-1);
                }

                sleep(1);
        }

        pthread_exit(NULL); //Kill thread
}
/***************************************************************
Print

Use: Your run of the mill print function. Is used to print
contents of a list that contains a pair of long and int values.
First checks to see if the list is empty, and if it is, lets
user know that the list is empty.Else, it prints the contents
of the list using an iterator to get the 1st and 2nd values.
Prints "P" to let user know which producer is responsible for
creating the widget and prints "W" to let user know which widget
it is referring to. Does this until the end of the list.

Parameters: None

Returns: Nothing
***************************************************************/
void Print()
{
	if(Buffer.empty())
	{
		cerr << "Buffer is empty.\n\n";
	}
	else
	{
		cerr << "Buffer now contains: ";
		for(list<pair<long,int>>::iterator it = Buffer.begin(); it != Buffer.end(); it++)
		{
			cerr << "P" << it->first << "W" << it->second << " ";
		}
		cerr << "\n\n";
	}
}
